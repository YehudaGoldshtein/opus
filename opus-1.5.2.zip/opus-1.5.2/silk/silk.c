int silk_function() { return 0; }
