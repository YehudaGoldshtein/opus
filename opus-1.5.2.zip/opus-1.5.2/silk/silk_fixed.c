int silk_fixed_function() { return 0; }
