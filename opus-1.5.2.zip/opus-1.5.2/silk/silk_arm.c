int silk_arm_function() { return 0; }
