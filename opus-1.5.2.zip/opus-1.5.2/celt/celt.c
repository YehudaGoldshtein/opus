int celt_function() { return 0; }
