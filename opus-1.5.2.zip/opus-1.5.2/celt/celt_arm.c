int celt_arm_function() { return 0; }
